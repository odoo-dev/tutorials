{
    'name': 'TDS Validation',
    'version': '19.0.2.0.0',
    'summary': 'TDS FVU Validation — Production Grade',
    'category': 'Tutorials',
    'author': 'Odoo',
    'depends': ['base', 'mail', 'web'],
    'data': [
        'security/ir.model.access.csv',
        'views/tds_validation_views.xml',
        'data/ir_config_parameter.xml',
    ],
    'installable': True,
    'license': 'LGPL-3',
}
