import logging
import os

from odoo import api, models, fields
from odoo.exceptions import UserError, ValidationError
from ..services.fvu_runner import FVURunner
from ..services.version_checker import FVUVersionChecker

_logger = logging.getLogger(__name__)

VALID_TDS_EXTENSIONS = {'.txt', '.fvu'}
VALID_CSI_EXTENSION = '.csi'


class TdsValidation(models.Model):
    _name = 'tds.validation'
    _description = 'TDS FVU Validation'
    _inherit = ['mail.thread']
    _order = 'create_date desc'

    name = fields.Char(
        string='Reference', required=True,
        default=lambda self: self.env['ir.sequence'].next_by_code('tds.validation') or 'New'
    )
    state = fields.Selection([
        ('draft', 'Draft'),
        ('running', 'Running'),
        ('done', 'Done'),
        ('failed', 'Failed'),
    ], default='draft', tracking=True)

    # ── Input files ───────────────────────────────────────────────
    tds_file = fields.Binary(
        string='TDS/TCS Input File',
        required=True,
        attachment=True,
        help='Upload .txt or .fvu file'
    )
    tds_filename = fields.Char(string='Filename')

    consolidate_file = fields.Binary(
        string='Challan/Consolidate File (.csi)',
        attachment=True,
        help='Upload .csi file for correction statements'
    )
    consolidate_filename = fields.Char(string='Consolidate Filename')

    # ── Output ────────────────────────────────────────────────────
    output_attachment_ids = fields.Many2many(
        'ir.attachment',
        'tds_val_att_rel', 'val_id', 'att_id',
        string='Output Files', readonly=True
    )
    error_message = fields.Text(readonly=True)

    # ── FVU version tracking ──────────────────────────────────────
    fvu_version_local = fields.Char(string='Local FVU Version', readonly=True)
    fvu_version_server = fields.Char(string='Server FVU Version', readonly=True)
    fvu_version_status = fields.Selection([
        ('unknown', 'Unknown'),
        ('current', 'Up-to-date'),
        ('warn', 'Minor outdated'),
        ('old', 'Old'),
        ('unverified', 'Unverified'),
    ], string='FVU Version Status', default='unknown', readonly=True)

    # ── Config ────────────────────────────────────────────────────
    @api.model
    def _get_jar_dir(self):
        """Read JAR directory from system parameters (single source of truth)."""
        return self.env['ir.config_parameter'].sudo().get_param(
            'tds_validation.jar_dir',
            '/home/odoo/Downloads/TDS_STANDALONE_FVU_9.4'
        )

    # ── Validation ────────────────────────────────────────────────

    @api.onchange('tds_filename')
    def _onchange_tds_filename(self):
        if self.tds_filename and not self._is_valid_tds_name(self.tds_filename):
            return {
                'warning': {
                    'title': 'Invalid Extension',
                    'message': 'TDS file must end with .txt or .fvu',
                }
            }

    @api.onchange('consolidate_filename')
    def _onchange_consolidate_filename(self):
        if self.consolidate_filename and not self._is_valid_csi_name(self.consolidate_filename):
            return {
                'warning': {
                    'title': 'Invalid Extension',
                    'message': 'Consolidate file must end with .csi',
                }
            }

    @staticmethod
    def _is_valid_tds_name(name):
        _, ext = os.path.splitext(name.lower())
        return ext in VALID_TDS_EXTENSIONS

    @staticmethod
    def _is_valid_csi_name(name):
        return name.lower().endswith(VALID_CSI_EXTENSION)

    # ── Actions ───────────────────────────────────────────────────

    def action_run_validation(self):
        self.ensure_one()

        if self.state == 'running':
            raise UserError('Already running.')
        if not self.tds_file:
            raise UserError('Upload TDS/TCS Input File.')
        if self.tds_filename and not self._is_valid_tds_name(self.tds_filename):
            raise ValidationError('TDS file must end with .txt or .fvu')
        if self.consolidate_filename and not self._is_valid_csi_name(self.consolidate_filename):
            raise ValidationError('Consolidate file must end with .csi')

        # ── 1. Version check ──
        self._check_fvu_version()

        # ── 2. State → Running ──
        self.write({'state': 'running', 'error_message': False})
        self.env.cr.commit()

        # ── 3. Run JAR ──
        jar_dir = self._get_jar_dir()
        runner = FVURunner(self.id, jar_dir)
        try:
            outputs = runner.run(
                tds_b64=self.tds_file,
                tds_filename=self.tds_filename,
                consolidate_b64=self.consolidate_file or None,
                consolidate_filename=self.consolidate_filename or None,
            )

            att_ids = []
            for f in outputs:
                att = self.env['ir.attachment'].create({
                    'name': f['name'],
                    'datas': f['b64'],
                    'res_model': self._name,
                    'res_id': self.id,
                    'description': 'TDS FVU Output',
                })
                att_ids.append(att.id)

            self.write({
                'state': 'done',
                'output_attachment_ids': [(6, 0, att_ids)],
            })
            self.message_post(body=f"✅ Validation complete. {len(att_ids)} file(s) attached.")

        except Exception as e:
            _logger.exception("TDS Validation failed [%s]", self.name)
            self.write({'state': 'failed', 'error_message': str(e)})
            self.message_post(body=f"❌ Failed: {e}")
            raise UserError(str(e)) from e
        finally:
            runner.cleanup()

    def _check_fvu_version(self):
        """Version check matching test.sh logic.

        Returns: result dict from checker.
        Raises UserError if major mismatch or server unreachable.
        """
        jar_dir = self._get_jar_dir()
        checker = FVUVersionChecker(jar_dir)
        result = checker.check()

        _logger.info(
            'FVU Version Check — Status: %s | Local: %s | Server: %s | %s',
            result['status'], result['local_version'],
            result.get('server_version', 'N/A'), result['message'],
        )

        status_map = {
            'error': 'unverified',
            'old': 'old',
            'warn': 'warn',
            'current': 'current',
        }
        self.write({
            'fvu_version_local': result['local_version'],
            'fvu_version_server': result.get('server_version', ''),
            'fvu_version_status': status_map.get(result['status'], 'unknown'),
        })

        if result['status'] == 'error':
            raise UserError(result['message'])
        if result['status'] == 'old':
            raise UserError(result['message'])
        if result['status'] == 'warn':
            _logger.warning(result['message'])
            self.message_post(body=f"⚠ {result['message']}")
            return result

        self.message_post(body=f"✅ {result['message']}")
        return result

    def action_reset(self):
        self.write({
            'state': 'draft',
            'error_message': False,
            'fvu_version_local': False,
            'fvu_version_server': False,
            'fvu_version_status': 'unknown',
        })
